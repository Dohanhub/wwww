/**
 * Ahmet Doğan Professional Profile - Main JavaScript
 * 
 * Features:
 * - Interactive UI elements
 * - Smooth animations
 * - Dark mode toggle
 * - Language switching
 * - Mobile menu handling
 * - Scroll effects
 */

document.addEventListener('DOMContentLoaded', function() {
  // Initialize all components
  initThemeToggle();
  initMobileMenu();
  initLanguageSwitch();
  initScrollEffects();
  initExpertiseCards();
  initContactForm();
  initParticlesBackground();
  
  // Add class to body when page is fully loaded
  document.body.classList.add('page-loaded');
});

/**
 * Theme Toggle Functionality
 */
function initThemeToggle() {
  const themeToggle = document.querySelector('.theme-toggle');
  const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
  
  // Check for saved theme preference or use the system preference
  const savedTheme = localStorage.getItem('theme');
  
  if (savedTheme === 'dark' || (!savedTheme && prefersDarkScheme.matches)) {
    document.body.classList.add('dark-mode');
    updateThemeIcon(true);
  }
  
  // Toggle theme when button is clicked
  themeToggle.addEventListener('click', function() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
    updateThemeIcon(isDarkMode);
  });
  
  // Update theme icon based on current mode
  function updateThemeIcon(isDarkMode) {
    const icon = themeToggle.querySelector('i');
    if (isDarkMode) {
      icon.classList.remove('fa-moon');
      icon.classList.add('fa-sun');
    } else {
      icon.classList.remove('fa-sun');
      icon.classList.add('fa-moon');
    }
  }
}

/**
 * Mobile Menu Functionality
 */
function initMobileMenu() {
  const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  
  if (!mobileMenuToggle || !navLinks) return;
  
  mobileMenuToggle.addEventListener('click', function() {
    navLinks.classList.toggle('active');
    
    // Update aria-expanded attribute for accessibility
    const isExpanded = navLinks.classList.contains('active');
    mobileMenuToggle.setAttribute('aria-expanded', isExpanded);
    
    // Toggle icon between hamburger and close
    const icon = mobileMenuToggle.querySelector('i');
    if (isExpanded) {
      icon.classList.remove('fa-bars');
      icon.classList.add('fa-times');
    } else {
      icon.classList.remove('fa-times');
      icon.classList.add('fa-bars');
    }
  });
  
  // Close mobile menu when a link is clicked
  const navLinkElements = navLinks.querySelectorAll('a');
  navLinkElements.forEach(link => {
    link.addEventListener('click', function() {
      if (window.innerWidth <= 768) {
        navLinks.classList.remove('active');
        mobileMenuToggle.setAttribute('aria-expanded', false);
        const icon = mobileMenuToggle.querySelector('i');
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
      }
    });
  });
}

/**
 * Language Switching Functionality
 */
function initLanguageSwitch() {
  const langToggles = document.querySelectorAll('.lang-toggle');
  
  // Check for saved language preference or use browser language
  const savedLang = localStorage.getItem('language') || 'en';
  document.documentElement.lang = savedLang;
  document.documentElement.dir = savedLang === 'ar' ? 'rtl' : 'ltr';
  
  // Update active state on language buttons
  langToggles.forEach(toggle => {
    if (toggle.dataset.lang === savedLang) {
      toggle.classList.add('active');
    }
    
    toggle.addEventListener('click', function() {
      const lang = this.dataset.lang;
      
      // Skip if button is disabled or already active
      if (this.disabled || this.classList.contains('active')) return;
      
      // Update HTML attributes
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
      
      // Save preference
      localStorage.setItem('language', lang);
      
      // Update active state on buttons
      langToggles.forEach(btn => {
        btn.classList.remove('active');
      });
      this.classList.add('active');
      
      // Reload page to apply language changes
      // window.location.reload();
      
      // Or alternatively, update text content without reloading
      updateTextContent(lang);
    });
  });
  
  // Function to update text content based on language
  function updateTextContent(lang) {
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(element => {
      const key = element.dataset.i18n;
      if (translations[lang] && translations[lang][key]) {
        element.textContent = translations[lang][key];
      }
    });
  }
  
  // Sample translations object (to be expanded)
  const translations = {
    en: {
      'nav.about': 'About',
      'nav.expertise': 'Expertise',
      'nav.experience': 'Experience',
      'nav.certifications': 'Certifications',
      'nav.contact': 'Contact',
      // Add more translations as needed
    },
    ar: {
      'nav.about': 'نبذة',
      'nav.expertise': 'الخبرات',
      'nav.experience': 'الخبرة المهنية',
      'nav.certifications': 'الشهادات',
      'nav.contact': 'اتصل بنا',
      // Add more translations as needed
    }
  };
}

/**
 * Scroll Effects
 */
function initScrollEffects() {
  // Highlight active nav link based on scroll position
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');
  
  window.addEventListener('scroll', function() {
    const scrollPosition = window.scrollY + 100;
    
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;
      const sectionId = section.getAttribute('id');
      
      if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
        navLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
          }
        });
      }
    });
    
    // Add shadow to header on scroll
    const header = document.querySelector('.header');
    if (window.scrollY > 10) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });
  
  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const targetId = this.getAttribute('href');
      
      if (targetId === '#') return;
      
      e.preventDefault();
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 80,
          behavior: 'smooth'
        });
      }
    });
  });
  
  // Animate elements on scroll
  const animatedElements = document.querySelectorAll('.animate-on-scroll');
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-fade-in');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  
  animatedElements.forEach(element => {
    observer.observe(element);
  });
}

/**
 * Expertise Cards Interaction
 */
function initExpertiseCards() {
  const expertiseCards = document.querySelectorAll('.expertise-card');
  
  expertiseCards.forEach(card => {
    // Add 3D tilt effect using vanilla-tilt.js if available
    if (typeof VanillaTilt !== 'undefined') {
      VanillaTilt.init(card, {
        max: 5,
        speed: 400,
        glare: true,
        'max-glare': 0.1,
        scale: 1.03
      });
    }
    
    // Add keyboard accessibility for hover content
    card.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const hoverContent = this.querySelector('.card-hover-content');
        hoverContent.style.opacity = hoverContent.style.opacity === '1' ? '0' : '1';
        hoverContent.style.transform = hoverContent.style.transform === 'translateY(0px)' ? 'translateY(10px)' : 'translateY(0px)';
        hoverContent.style.pointerEvents = hoverContent.style.pointerEvents === 'auto' ? 'none' : 'auto';
      }
    });
  });
}

/**
 * Contact Form Handling
 */
function initContactForm() {
  const contactForm = document.querySelector('.contact-form');
  
  if (!contactForm) return;
  
  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form data
    const formData = new FormData(this);
    const formValues = Object.fromEntries(formData.entries());
    
    // Simple validation
    let isValid = true;
    const requiredFields = contactForm.querySelectorAll('[required]');
    
    requiredFields.forEach(field => {
      if (!field.value.trim()) {
        isValid = false;
        field.classList.add('is-invalid');
      } else {
        field.classList.remove('is-invalid');
      }
    });
    
    if (!isValid) {
      showFormMessage('Please fill in all required fields.', 'error');
      return;
    }
    
    // Email validation
    const emailField = contactForm.querySelector('input[type="email"]');
    if (emailField && !isValidEmail(emailField.value)) {
      emailField.classList.add('is-invalid');
      showFormMessage('Please enter a valid email address.', 'error');
      return;
    }
    
    // Simulate form submission
    const submitButton = contactForm.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    
    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    
    // Simulate API call with timeout
    setTimeout(() => {
      submitButton.disabled = false;
      submitButton.textContent = originalText;
      
      // Show success message
      showFormMessage('Thank you for your message! I will get back to you soon.', 'success');
      
      // Reset form
      contactForm.reset();
    }, 1500);
  });
  
  // Helper function to validate email
  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
  
  // Helper function to show form messages
  function showFormMessage(message, type) {
    let messageElement = contactForm.querySelector('.form-message');
    
    if (!messageElement) {
      messageElement = document.createElement('div');
      messageElement.className = 'form-message';
      contactForm.appendChild(messageElement);
    }
    
    messageElement.textContent = message;
    messageElement.className = `form-message ${type}`;
    
    // Auto-hide message after 5 seconds
    setTimeout(() => {
      messageElement.classList.add('fade-out');
      setTimeout(() => {
        messageElement.remove();
      }, 300);
    }, 5000);
  }
}

/**
 * Particles Background
 */
function initParticlesBackground() {
  if (typeof particlesJS === 'undefined') return;
  
  particlesJS('particles-js', {
    particles: {
      number: {
        value: 50,
        density: {
          enable: true,
          value_area: 800
        }
      },
      color: {
        value: '#006c35'
      },
      shape: {
        type: 'circle',
        stroke: {
          width: 0,
          color: '#000000'
        }
      },
      opacity: {
        value: 0.5,
        random: false,
        anim: {
          enable: false
        }
      },
      size: {
        value: 3,
        random: true,
        anim: {
          enable: false
        }
      },
      line_linked: {
        enable: true,
        distance: 150,
        color: '#006c35',
        opacity: 0.4,
        width: 1
      },
      move: {
        enable: true,
        speed: 2,
        direction: 'none',
        random: false,
        straight: false,
        out_mode: 'out',
        bounce: false,
        attract: {
          enable: false,
          rotateX: 600,
          rotateY: 1200
        }
      }
    },
    interactivity: {
      detect_on: 'canvas',
      events: {
        onhover: {
          enable: true,
          mode: 'grab'
        },
        onclick: {
          enable: true,
          mode: 'push'
        },
        resize: true
      },
      modes: {
        grab: {
          distance: 140,
          line_linked: {
            opacity: 1
          }
        },
        push: {
          particles_nb: 4
        }
      }
    },
    retina_detect: true
  });
}/**
 * Ahmet Doğan Professional Profile - Main JavaScript
 * 
 * Features:
 * - Interactive UI elements
 * - Smooth animations
 * - Dark mode toggle
 * - Language switching
 * - Mobile menu handling
 * - Scroll effects
 */

document.addEventListener('DOMContentLoaded', function() {
  // Initialize all components
  initThemeToggle();
  initMobileMenu();
  initLanguageSwitch();
  initScrollEffects();
  initExpertiseCards();
  initContactForm();
  initParticlesBackground();
  
  // Add class to body when page is fully loaded
  document.body.classList.add('page-loaded');
});

/**
 * Theme Toggle Functionality
 */
function initThemeToggle() {
  const themeToggle = document.querySelector('.theme-toggle');
  const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
  
  // Check for saved theme preference or use the system preference
  const savedTheme = localStorage.getItem('theme');
  
  if (savedTheme === 'dark' || (!savedTheme && prefersDarkScheme.matches)) {
    document.body.classList.add('dark-mode');
    updateThemeIcon(true);
  }
  
  // Toggle theme when button is clicked
  themeToggle.addEventListener('click', function() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
    updateThemeIcon(isDarkMode);
  });
  
  // Update theme icon based on current mode
  function updateThemeIcon(isDarkMode) {
    const icon = themeToggle.querySelector('i');
    if (isDarkMode) {
      icon.classList.remove('fa-moon');
      icon.classList.add('fa-sun');
    } else {
      icon.classList.remove('fa-sun');
      icon.classList.add('fa-moon');
    }
  }
}

/**
 * Mobile Menu Functionality
 */
function initMobileMenu() {
  const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  
  if (!mobileMenuToggle || !navLinks) return;
  
  mobileMenuToggle.addEventListener('click', function() {
    navLinks.classList.toggle('active');
    
    // Update aria-expanded attribute for accessibility
    const isExpanded = navLinks.classList.contains('active');
    mobileMenuToggle.setAttribute('aria-expanded', isExpanded);
    
    // Toggle icon between hamburger and close
    const icon = mobileMenuToggle.querySelector('i');
    if (isExpanded) {
      icon.classList.remove('fa-bars');
      icon.classList.add('fa-times');
    } else {
      icon.classList.remove('fa-times');
      icon.classList.add('fa-bars');
    }
  });
  
  // Close mobile menu when a link is clicked
  const navLinkElements = navLinks.querySelectorAll('a');
  navLinkElements.forEach(link => {
    link.addEventListener('click', function() {
      if (window.innerWidth <= 768) {
        navLinks.classList.remove('active');
        mobileMenuToggle.setAttribute('aria-expanded', false);
        const icon = mobileMenuToggle.querySelector('i');
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
      }
    });
  });
}

/**
 * Language Switching Functionality
 */
function initLanguageSwitch() {
  const langToggles = document.querySelectorAll('.lang-toggle');
  
  // Check for saved language preference or use browser language
  const savedLang = localStorage.getItem('language') || 'en';
  document.documentElement.lang = savedLang;
  document.documentElement.dir = savedLang === 'ar' ? 'rtl' : 'ltr';
  
  // Update active state on language buttons
  langToggles.forEach(toggle => {
    if (toggle.dataset.lang === savedLang) {
      toggle.classList.add('active');
    }
    
    toggle.addEventListener('click', function() {
      const lang = this.dataset.lang;
      
      // Skip if button is disabled or already active
      if (this.disabled || this.classList.contains('active')) return;
      
      // Update HTML attributes
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
      
      // Save preference
      localStorage.setItem('language', lang);
      
      // Update active state on buttons
      langToggles.forEach(btn => {
        btn.classList.remove('active');
      });
      this.classList.add('active');
      
      // Reload page to apply language changes
      // window.location.reload();
      
      // Or alternatively, update text content without reloading
      updateTextContent(lang);
    });
  });
  
  // Function to update text content based on language
  function updateTextContent(lang) {
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(element => {
      const key = element.dataset.i18n;
      if (translations[lang] && translations[lang][key]) {
        element.textContent = translations[lang][key];
      }
    });
  }
  
  // Sample translations object (to be expanded)
  const translations = {
    en: {
      'nav.about': 'About',
      'nav.expertise': 'Expertise',
      'nav.experience': 'Experience',
      'nav.certifications': 'Certifications',
      'nav.contact': 'Contact',
      // Add more translations as needed
    },
    ar: {
      'nav.about': 'نبذة',
      'nav.expertise': 'الخبرات',
      'nav.experience': 'الخبرة المهنية',
      'nav.certifications': 'الشهادات',
      'nav.contact': 'اتصل بنا',
      // Add more translations as needed
    }
  };
}

/**
 * Scroll Effects
 */
function initScrollEffects() {
  // Highlight active nav link based on scroll position
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');
  
  window.addEventListener('scroll', function() {
    const scrollPosition = window.scrollY + 100;
    
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;
      const sectionId = section.getAttribute('id');
      
      if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
        navLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
          }
        });
      }
    });
    
    // Add shadow to header on scroll
    const header = document.querySelector('.header');
    if (window.scrollY > 10) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });
  
  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const targetId = this.getAttribute('href');
      
      if (targetId === '#') return;
      
      e.preventDefault();
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 80,
          behavior: 'smooth'
        });
      }
    });
  });
  
  // Animate elements on scroll
  const animatedElements = document.querySelectorAll('.animate-on-scroll');
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-fade-in');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  
  animatedElements.forEach(element => {
    observer.observe(element);
  });
}

/**
 * Expertise Cards Interaction
 */
function initExpertiseCards() {
  const expertiseCards = document.querySelectorAll('.expertise-card');
  
  expertiseCards.forEach(card => {
    // Add 3D tilt effect using vanilla-tilt.js if available
    if (typeof VanillaTilt !== 'undefined') {
      VanillaTilt.init(card, {
        max: 5,
        speed: 400,
        glare: true,
        'max-glare': 0.1,
        scale: 1.03
      });
    }
    
    // Add keyboard accessibility for hover content
    card.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const hoverContent = this.querySelector('.card-hover-content');
        hoverContent.style.opacity = hoverContent.style.opacity === '1' ? '0' : '1';
        hoverContent.style.transform = hoverContent.style.transform === 'translateY(0px)' ? 'translateY(10px)' : 'translateY(0px)';
        hoverContent.style.pointerEvents = hoverContent.style.pointerEvents === 'auto' ? 'none' : 'auto';
      }
    });
  });
}

/**
 * Contact Form Handling
 */
function initContactForm() {
  const contactForm = document.querySelector('.contact-form');
  
  if (!contactForm) return;
  
  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form data
    const formData = new FormData(this);
    const formValues = Object.fromEntries(formData.entries());
    
    // Simple validation
    let isValid = true;
    const requiredFields = contactForm.querySelectorAll('[required]');
    
    requiredFields.forEach(field => {
      if (!field.value.trim()) {
        isValid = false;
        field.classList.add('is-invalid');
      } else {
        field.classList.remove('is-invalid');
      }
    });
    
    if (!isValid) {
      showFormMessage('Please fill in all required fields.', 'error');
      return;
    }
    
    // Email validation
    const emailField = contactForm.querySelector('input[type="email"]');
    if (emailField && !isValidEmail(emailField.value)) {
      emailField.classList.add('is-invalid');
      showFormMessage('Please enter a valid email address.', 'error');
      return;
    }
    
    // Simulate form submission
    const submitButton = contactForm.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    
    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    
    // Simulate API call with timeout
    setTimeout(() => {
      submitButton.disabled = false;
      submitButton.textContent = originalText;
      
      // Show success message
      showFormMessage('Thank you for your message! I will get back to you soon.', 'success');
      
      // Reset form
      contactForm.reset();
    }, 1500);
  });
  
  // Helper function to validate email
  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
  
  // Helper function to show form messages
  function showFormMessage(message, type) {
    let messageElement = contactForm.querySelector('.form-message');
    
    if (!messageElement) {
      messageElement = document.createElement('div');
      messageElement.className = 'form-message';
      contactForm.appendChild(messageElement);
    }
    
    messageElement.textContent = message;
    messageElement.className = `form-message ${type}`;
    
    // Auto-hide message after 5 seconds
    setTimeout(() => {
      messageElement.classList.add('fade-out');
      setTimeout(() => {
        messageElement.remove();
      }, 300);
    }, 5000);
  }
}

/**
 * Particles Background
 */
function initParticlesBackground() {
  if (typeof particlesJS === 'undefined') return;
  
  particlesJS('particles-js', {
    particles: {
      number: {
        value: 50,
        density: {
          enable: true,
          value_area: 800
        }
      },
      color: {
        value: '#006c35'
      },
      shape: {
        type: 'circle',
        stroke: {
          width: 0,
          color: '#000000'
        }
      },
      opacity: {
        value: 0.5,
        random: false,
        anim: {
          enable: false
        }
      },
      size: {
        value: 3,
        random: true,
        anim: {
          enable: false
        }
      },
      line_linked: {
        enable: true,
        distance: 150,
        color: '#006c35',
        opacity: 0.4,
        width: 1
      },
      move: {
        enable: true,
        speed: 2,
        direction: 'none',
        random: false,
        straight: false,
        out_mode: 'out',
        bounce: false,
        attract: {
          enable: false,
          rotateX: 600,
          rotateY: 1200
        }
      }
    },
    interactivity: {
      detect_on: 'canvas',
      events: {
        onhover: {
          enable: true,
          mode: 'grab'
        },
        onclick: {
          enable: true,
          mode: 'push'
        },
        resize: true
      },
      modes: {
        grab: {
          distance: 140,
          line_linked: {
            opacity: 1
          }
        },
        push: {
          particles_nb: 4
        }
      }
    },
    retina_detect: true
  });
}